<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\HomeController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\WalletController;

use App\Http\Controllers\Admin\ApiLogController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Admin\ProviderController;
use App\Http\Controllers\Admin\ServiceController;
use App\Http\Controllers\Admin\TransactionController;
use App\Http\Controllers\Admin\UserController as AdminUserController;
use App\Http\Controllers\Admin\TopupController as AdminTopupController;

/*
|--------------------------------------------------------------------------
| Halaman Publik
|--------------------------------------------------------------------------
*/

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/services', [HomeController::class, 'services'])->name('services.index');

/*
|--------------------------------------------------------------------------
| Dashboard Bawaan (setelah login & verifikasi)
|--------------------------------------------------------------------------
*/
Route::get('/dashboard', [\App\Http\Controllers\DashboardController::class, 'index'])->middleware(['auth', 'verified'])->name('dashboard');

/*
|--------------------------------------------------------------------------
| Profil User (Laravel Breeze)
|--------------------------------------------------------------------------
*/
Route::middleware('auth')->group(function () {
    Route::get('/profile',  [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

/*
|--------------------------------------------------------------------------
| Admin Area
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'verified', 'admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        // Dashboard
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

        // Users (Admin)
        // Route::get('/users',            [\App\Http\Controllers\Admin\UserController::class, 'index'])->name('users.index');
        // Route::get('/users/export',     [\App\Http\Controllers\Admin\UserController::class, 'export'])->name('users.export');
        // Route::get('/users/{user}',     [\App\Http\Controllers\Admin\AdminUserController::class, 'show'])->name('users.show');
        // USERS (Admin)
        // Admin — Users
        Route::get('/users',                [AdminUserController::class, 'index'])->name('users.index');
        Route::get('/users/export',        [AdminUserController::class, 'export'])->name('users.export');
        Route::get('/users/{user}',        [AdminUserController::class, 'show'])->name('users.show');
        Route::get('/users/{user}/edit',   [AdminUserController::class, 'edit'])->name('users.edit');
        Route::put('/users/{user}',        [AdminUserController::class, 'update'])->name('users.update');
        Route::delete('/users/{user}',     [AdminUserController::class, 'destroy'])->name('users.destroy');
        Route::post('/users/{user}/toggle-active', [AdminUserController::class, 'toggleActive'])
            ->name('users.toggle-active');

        // Providers
        Route::get('/providers',                 [ProviderController::class, 'index'])->name('providers.index');
        Route::get('/providers/{provider}/edit', [ProviderController::class, 'edit'])->name('providers.edit');
        Route::put('/providers/{provider}',      [ProviderController::class, 'update'])->name('providers.update');
        Route::post('/providers/{provider}/reveal-key', [ProviderController::class, 'revealKey'])
            ->name('providers.reveal-key')
            ->middleware('throttle:reveal-api-key');

        // Services
        Route::resource('services', ServiceController::class)->only(['index', 'edit', 'update']);

        // Categories
        Route::get('/categories',                 [CategoryController::class, 'index'])->name('categories.index');
        Route::get('/categories/{category}/edit', [CategoryController::class, 'edit'])->name('categories.edit');
        Route::put('/categories/{category}',      [CategoryController::class, 'update'])->name('categories.update');

        // API Logs
        Route::get('/api-logs',       [ApiLogController::class, 'index'])->name('api-logs.index');
        Route::get('/api-logs/{log}', [ApiLogController::class, 'show'])->name('api-logs.show');

        // Orders (Admin monitor)
        Route::get('/orders/export', [AdminOrderController::class, 'export'])
            ->name('orders.export');
        Route::post('/orders/bulk-status-check', [AdminOrderController::class, 'bulkStatusCheck'])
            ->name('orders.bulk-status-check')
            ->middleware('throttle:order-status-check');
        Route::get('/orders',         [AdminOrderController::class, 'index'])->name('orders.index');
        Route::get('/orders/{order}', [AdminOrderController::class, 'show'])->name('orders.show');
        Route::post('/orders/{order}/status-check', [AdminOrderController::class, 'statusCheck'])
            ->name('orders.status-check')
            ->middleware('throttle:order-status-check');

        // Transactions (Admin monitor)
        Route::get('/transactions', [TransactionController::class, 'index']) // @phpstan-ignore-line
            ->name('transactions.index');
        Route::get('/transactions/export', [TransactionController::class, 'export']) // @phpstan-ignore-line
            ->name('transactions.export');

        Route::get('/topups',                [AdminTopupController::class, 'index'])->name('topups.index');
        Route::get('/topups/{topup}',        [AdminTopupController::class, 'show'])->name('topups.show');
        Route::post('/topups/{topup}/approve', [AdminTopupController::class, 'approve'])->name('topups.approve');
        Route::post('/topups/{topup}/reject', [AdminTopupController::class, 'reject'])->name('topups.reject');

        // ... dalam group admin (auth, verified, admin)
        Route::resource('payment-methods', \App\Http\Controllers\Admin\PaymentMethodController::class)
            ->except(['show'])
            ->names('payment-methods');

        // Tickets (Admin)
        Route::get('/tickets',                [\App\Http\Controllers\Admin\TicketController::class, 'index'])->name('tickets.index');
        Route::get('/tickets/{ticket}',       [\App\Http\Controllers\Admin\TicketController::class, 'show'])->name('tickets.show');
        Route::post('/tickets/{ticket}/reply',[\App\Http\Controllers\Admin\TicketController::class, 'reply'])
            ->name('tickets.reply')
            ->middleware('throttle:ticket-reply');
        Route::put('/tickets/{ticket}/status',[\App\Http\Controllers\Admin\TicketController::class, 'updateStatus'])->name('tickets.status');
        // (opsional) download lampiran
        Route::get('/ticket-messages/{message}/download', [\App\Http\Controllers\Admin\TicketController::class, 'download'])
            ->name('tickets.download');
    });

/*
|--------------------------------------------------------------------------
| User — Orders
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'verified'])->group(function () {
    // Form order
    Route::get('/orders/create/{service}', [OrderController::class, 'create'])->name('orders.create');

    // Submit order (opsional: rate-limit "order-submit" bila sudah didefinisikan)
    Route::post('/orders/{service}', [OrderController::class, 'store'])
        ->name('orders.store')
        ->middleware('throttle:order-submit');

    // List & detail
    Route::get('/orders',              [OrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/show/{order}', [OrderController::class, 'show'])->name('orders.show');

    // Cek status manual (opsional: rate-limit khusus)
    Route::post('/orders/{order}/status-check', [OrderController::class, 'statusCheck'])
        ->name('orders.status-check')
        ->middleware('throttle:order-status-check');
});

/*
|--------------------------------------------------------------------------
| User — Wallet
|--------------------------------------------------------------------------
*/
// Route::middleware(['auth', 'verified'])->group(function () {
//     Route::get('/wallet/topup',        [WalletController::class, 'create'])->name('wallet.topup');

//     // Submit topup (opsional: rate-limit "topup-submit" bila sudah didefinisikan)
//     Route::post('/wallet/topup',       [WalletController::class, 'store'])
//         ->name('wallet.topup.store')
//         ->middleware('throttle:topup-submit');

//     Route::get('/wallet/transactions', [WalletController::class, 'transactions'])->name('wallet.transactions');

// });
Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/wallet/topup',  [\App\Http\Controllers\WalletController::class, 'create'])->name('wallet.topup');
    Route::post('/wallet/topup', [\App\Http\Controllers\WalletController::class, 'store'])
        ->name('wallet.topup.store')
        ->middleware('throttle:topup-submit');

    Route::get('/wallet/transactions', [\App\Http\Controllers\WalletController::class, 'transactions'])
        ->name('wallet.transactions');
});


// USER — Tickets
Route::middleware(['auth','verified'])->group(function () {
    // Tickets (User)
    Route::get('/tickets',                 [\App\Http\Controllers\TicketController::class, 'index'])->name('tickets.index');
    Route::get('/tickets/create',          [\App\Http\Controllers\TicketController::class, 'create'])->name('tickets.create');
    Route::post('/tickets',                [\App\Http\Controllers\TicketController::class, 'store'])
        ->name('tickets.store')->middleware('throttle:ticket-create');
    Route::get('/tickets/{ticket}',        [\App\Http\Controllers\TicketController::class, 'show'])->name('tickets.show');
    Route::post('/tickets/{ticket}/reply', [\App\Http\Controllers\TicketController::class, 'reply'])
        ->name('tickets.reply')->middleware('throttle:ticket-reply');
    Route::get('/ticket-messages/{message}/download', [\App\Http\Controllers\TicketController::class, 'download'])
        ->name('tickets.download');
});



require __DIR__ . '/auth.php';

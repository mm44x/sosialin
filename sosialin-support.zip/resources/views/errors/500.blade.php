@extends('errors.minimal', [
    'code' => 500,
    'title' => 'Waduh, ada yang berantakan di dapur kami! Tenang, tim kami sedang memperbaikinya.',
    'message' => 'Bikin kopi susunya tumpah,
Mau bikin kue, eh, gosong pula.
Maaf, server kami lagi ada masalah,
Coba lagi nanti ea, jangan putus asa.',
])

@extends('errors.minimal', [
    'code' => 429,
    'title' => 'Sabar, sabar! Server juga butuh napas, jangan digempur terus-terusan.',
    'message' => '
    Nonton konser di tengah lapangan,
Pulangnya malah kehujanan.
Kamu nge-klik-nya kebanyakan,
Kasih jeda dulu, ya, perlahan-lahan.',
])

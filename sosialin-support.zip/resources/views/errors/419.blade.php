@extends('errors.minimal', [
    'code' => 419,
    'title' => 'Sesi Anda telah berakhir, seperti cinta yang telah usang.',
    'message' => '
    Ikan hiu makan donat,
    Selamat, cintamu tamat!',
])

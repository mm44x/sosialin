@extends('errors.minimal', [
    'code' => 404,
    'title' => 'Ibarat mencari jodoh yang tak kunjung ada, halaman yang Anda tuju ternyata tiada.',
    'message' => 'Beli buah duku di pasar mingguan,
Jangan lupa beli alpukat.
Aduh, halaman yang kamu tuju nggak ketemu, Tuan,
Mungkin dia lagi pindah alamat.',
])

{{-- Ganti konten ini dengan SVG wordmark “Sosialin” Anda --}}
<span class="text-xl tracking-tight">Sosialin</span>
